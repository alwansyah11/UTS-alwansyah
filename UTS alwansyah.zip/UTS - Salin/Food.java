import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
public class Food  extends Actor
{
    public Food()
    {
       GreenfootImage food = new GreenfootImage("apple1.png");
       setImage(food);
    }   
}
