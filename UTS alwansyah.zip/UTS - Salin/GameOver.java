import greenfoot.*;

public class GameOver extends Actor {
    public GameOver() {
        GreenfootImage image = new GreenfootImage("game_over.png"); // Ganti "gameover.png" dengan nama berkas gambar yang ingin Anda gunakan
        setImage(image);
    }
}
